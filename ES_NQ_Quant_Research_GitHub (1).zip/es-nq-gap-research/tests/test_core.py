import numpy as np
import pandas as pd
from gapresearch.core import three_candle_fvg,validate,_exit
from gapresearch.stats import daily_returns,performance,paired_block_bootstrap

def test_bullish_fvg():
    x=pd.DataFrame({'high':[100,102,105],'low':[98,99,103]})
    assert three_candle_fvg(x,1)==[(2,101.5)]
    assert three_candle_fvg(x,-1)==[]

def test_invalid_ohlc():
    x=pd.DataFrame([dict(symbol='ES',timestamp='2025-01-01T14:30:00Z',open=10,high=9,low=8,close=10,volume=1)])
    try:validate(x);assert False
    except ValueError:pass

def test_stop_first_ambiguity():
    bars=pd.DataFrame([{'high':110,'low':90,'close':100,'timestamp':'t'}])
    assert _exit(bars,0,100,1,5,2,0)[2]=='stop'

def test_zero_days_included():
    events=pd.DataFrame([{'symbol':'ES','date':'2025-01-02'},{'symbol':'ES','date':'2025-01-03'}])
    trades=pd.DataFrame([{'symbol':'ES','date':'2025-01-02','strategy':'immediate','return_on_capital':0.01}])
    d=daily_returns(trades,events)
    assert len(d)==2 and d.loc[('ES','2025-01-03'),'immediate']==0

def test_bootstrap_deterministic():
    a=np.arange(30)/10000;b=a+0.001
    assert paired_block_bootstrap(a,b,seed=3)==paired_block_bootstrap(a,b,seed=3)

def test_drawdown():
    x=performance([0.1,-0.2,0.1])
    assert np.isclose(x['max_drawdown'],-0.2)
