# ES/NQ Intraday Gap Continuation — Quantitative Research

**A reproducible empirical framework comparing immediate opening-gap continuation with an ICT-inspired FVG retracement model in E-mini S&P 500 (ES) and Nasdaq-100 (NQ) futures.**

![Python](https://img.shields.io/badge/Python-3.10%2B-blue) ![Tests](https://img.shields.io/badge/pytest-included-brightgreen) ![Status](https://img.shields.io/badge/Research-prototype-orange) ![License](https://img.shields.io/badge/License-MIT-lightgrey)

> **Research status (November 2026):** Strategy implementations and tests are included. **No licensed CME intraday dataset has been supplied or analyzed; no realized Sharpe, regression coefficients, p-values, or alpha claims are reported.** This is a research prototype, not a validated live trading system.

## Research question

Do gaps between the previous regular trading hours (RTH) close and the next 09:30 ET cash-market open exhibit intraday continuation in ES/NQ? Does waiting for an objectively defined ICT-inspired Fair Value Gap (FVG) retracement improve daily risk-adjusted performance versus a simple opening-range baseline?

## Research design

| Component | Strategy A: immediate | Strategy B: ICT-inspired retracement |
|---|---|---|
| Eligibility | >= 0.25% absolute RTH gap | Same eligible gap days |
| Signal | Gap direction | Opening-range break + 3-candle FVG + later midpoint retracement |
| Entry | 09:45 ET next bar open | Next bar open after completed retracement, before 11:30 ET |
| Exit | Fixed stop, 2R target, 15:55 time stop | Identical |
| Missing signal | Not applicable | Zero return on eligible no-trade days |
| Comparison | Net daily return | Paired daily return on same eligible dates |

**Definitions are deliberately narrow.** An opening-range break is not a full ICT market-structure shift. The FVG implementation is a mechanical proxy, not a claim that discretionary ICT theory has been validated.

## Installation (Windows PowerShell or macOS/Linux)

```bash
python -m venv .venv
# Windows: .venv\Scripts\activate
# macOS/Linux: source .venv/bin/activate
pip install -e '.[dev]'
pytest -q
```

## Run on actual futures data

Acquire legitimate CME one-minute ES/NQ data, normalize timestamps to **UTC** and instrument symbols to `ES` / `NQ`, then:

```bash
gapresearch --csv data/es_nq_1min.csv --output results
```

Expected columns: `symbol,timestamp,open,high,low,close,volume`. Timestamp is the minute's **start** in UTC. See [data contract](docs/DATA.md). Raw market data is intentionally not included.

Outputs: `trades.csv`, `events.csv`, `daily_returns.csv`, `walkforward_predictions.csv`, `summary.txt`.

## Econometrics and validation

- **HAC OLS:** gap magnitude, downside gap indicator, and NQ dummy against signed RTH intraday return.
- **Walk-forward logistic regression:** expanding-window continuation probability, scored with Brier and ROC AUC.
- **Paired 5-day block bootstrap:** confidence interval for ICT minus immediate average daily return.
- **Risk:** annualized Sharpe, Sortino, drawdown, and return; daily zero-trade observations retained.
- **Holdout policy:** historical development sample through 2025; reserve 2026 for final validation once a full vetted dataset is available.

## Limitations (read before interpreting outputs)

1. The prototype uses one-minute bars; stop and target in the same minute are resolved **stop-first**, but actual fills and stop gap-through are not simulated.
2. Round-trip cost assumptions are placeholders and may underestimate actual slippage and fees.
3. Continuous futures construction, roll schedules, early-close handling, and data integrity must be audited by the researcher.
4. Fixed stops and trade sizing are not yet optimized or independently validated.
5. The bootstrap resamples eligible days, not a complete unconditional annual trading calendar. The reported Sharpe is therefore **conditional on eligible gap days**, not a whole-year investment return.
6. Neither predictive significance nor positive backtest P&L establishes causal alpha or future profitability.

Read the [full methodology](docs/METHODOLOGY.md) and [data requirements](docs/DATA.md).

## Repository layout

```text
src/gapresearch/       Signals, backtesting, econometrics, CLI
 tests/                Unit tests for signal and risk conventions
 docs/                 Research protocol and data contract
 data/                 Local licensed data (gitignored)
 results/              Generated research outputs (gitignored)
 .github/workflows/     CI tests
```

## Roadmap

- [x] Implement deterministic gap and FVG signal definitions
- [x] Implement conservative stop-first backtest and costs
- [x] Add paired bootstrap, HAC OLS, and walk-forward classifier
- [x] Add automated tests and GitHub Actions CI
- [ ] Ingest and audit licensed CME ES/NQ 1-minute history
- [ ] Add missing-bar, early-close, and contract-roll validation
- [ ] Add realistic execution simulation and slippage stress testing
- [ ] Publish real sample/holdout results with confidence intervals
- [ ] Add research charts, trade examples, and reproducibility report

## Disclosure

Educational research software only. Not financial advice, investment recommendations, or a live trading system. No historical performance results have been fabricated.
