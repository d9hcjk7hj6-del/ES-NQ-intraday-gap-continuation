# Pre-registered research methodology (v0.1)

## Scope and estimands
- Instruments: continuous front-month ES and NQ futures, adjusted consistently by data vendor. Never mix contracts without roll rules.
- Primary event: 09:30 ET open relative to prior complete RTH close (last minute before 16:00 ET).
- Eligible gap: absolute percentage >= 0.25%; a *cash-session gap*, not a CME session gap.
- Primary outcome: realized net daily strategy return per $100,000 initial capital, with flat zero on eligible no-trade days.
- Primary contrast: paired daily ICT-minus-immediate return by instrument. Do not compare only filled ICT trades (selection bias).

## Strategy A: immediate continuation
At 09:45 enter at first available 1-minute open in gap direction. Fixed instrument stop, 2R target, stop-first if same-bar ambiguity. Liquidate by 15:55 ET. No overnight holdings.

## Strategy B: ICT-inspired retracement proxy
After first 15 minutes, require (1) close outside initial opening range in gap direction and (2) a directional three-candle FVG confirmed at that close. Wait for a *later* completed bar to touch the FVG midpoint, then enter at next bar open, before 11:30. This is a strict mechanical proxy, NOT a complete representation of discretionary ICT concepts. No unconfirmed signal may be used.

## Costs and sizing
ES $50/point; NQ $20/point. Default ES 8-point stop, NQ 35-point stop; modeled round-trip all-in costs 0.5 ES point and 2 NQ points. Contract count = floor($1000 / stop risk per contract), minimum one required. These are **illustrative assumptions**, not verified execution estimates. No margin interest, contract roll fees, spread dynamics, market impact, gaps through stops, or tick-size fill modeling. Results cannot be considered live-tradable without these extensions.

## Statistics
- Per-instrument annualized Sharpe and Sortino on eligible daily returns, 252 trading days/year.
- Paired moving-block bootstrap of mean daily return difference, 5-day blocks, 2,000 resamples, seeded.
- HAC OLS: signed 09:30-to-15:55 price return vs abs gap, NQ dummy and downside-gap dummy; 5-lag HAC standard errors. Coefficients are associative, not causal.
- Expanding-window logistic regression predicting signed positive open-to-15:55 return using only 09:30-observable gap features; Brier score and ROC AUC on held-out dates. Default minimum 200 unique training dates.

## Research controls / planned upgrades
- Reserve 2026 as untouched final holdout; train/tune only on earlier years.
- Calendar-aligned paired ES/NQ tests, block bootstrap with multiple block sizes, Newey-West sensitivity.
- Benchmark gap-size bins, positive/negative gap asymmetry, prior-day volatility, CPI/FOMC flags.
- Realistic stop orders, slippage stress, tick rounding, futures roll, holidays, early closes, DST, missing-minute audits.
- Family-wise multiple-testing correction if sweeping thresholds; no retrospective parameter optimization on holdout.
- Current prototype does not implement liquidity sweeps, MSS/CHOCH, order blocks, or volume-confirmed displacement. Do not claim it does.
