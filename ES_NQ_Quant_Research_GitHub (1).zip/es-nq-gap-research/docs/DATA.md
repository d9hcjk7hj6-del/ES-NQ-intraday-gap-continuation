# Data contract

Provide one-minute OHLCV data as CSV with columns:

`symbol,timestamp,open,high,low,close,volume`

- `symbol`: ES or NQ (vendor contract identifiers must be normalized).
- `timestamp`: timezone-aware UTC ISO-8601 timestamp representing the **start** of the minute.
- OHLC prices: USD index points; volume nonnegative.
- Include 09:30 through 15:55 ET on each eligible full session, and previous full RTH day.
- Source must be legitimate CME historical futures data. Document vendor, extraction date, continuous contract construction, and roll policy in your published analysis.
- Never commit licensed market data to public GitHub without redistribution permission.
- Do not silently interpolate missing bars; audit first.

Example (schema only, NOT real market data):

```csv
symbol,timestamp,open,high,low,close,volume
ES,2025-01-02T14:30:00Z,5000,5002,4999,5001,123
```

DST matters: 09:30 New York is 14:30 UTC in winter and 13:30 UTC in summer.
