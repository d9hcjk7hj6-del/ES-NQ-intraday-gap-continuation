"""Research statistics. Daily zero-return days included in all comparisons."""
import numpy as np
import pandas as pd
from scipy import stats

def daily_returns(trades, events):
    if events.empty: return pd.DataFrame()
    index=pd.MultiIndex.from_frame(events[['symbol','date']].drop_duplicates())
    if trades.empty:
        return pd.DataFrame(0.,index=index,columns=['immediate','ict_retracement'])
    t=trades.groupby(['symbol','date','strategy']).return_on_capital.sum().unstack('strategy')
    return t.reindex(index=index,columns=['immediate','ict_retracement']).fillna(0).sort_index()

def performance(returns, annual_days=252):
    x=np.asarray(returns,dtype=float)
    if len(x)<2:return dict(n_days=len(x),sharpe=np.nan,sortino=np.nan,max_drawdown=np.nan,annualized_return=np.nan)
    equity=np.cumprod(1+x)
    vol=x.std(ddof=1)
    downside=np.sqrt(np.mean(np.minimum(x,0)**2))
    return dict(n_days=len(x),sharpe=float(np.sqrt(annual_days)*x.mean()/vol) if vol>0 else np.nan,
                sortino=float(np.sqrt(annual_days)*x.mean()/downside) if downside>0 else np.nan,
                max_drawdown=float(np.min(equity/np.maximum.accumulate(np.r_[1.,equity])[1:]-1)),
                annualized_return=float(equity[-1]**(annual_days/len(x))-1) if equity[-1]>0 else np.nan)

def paired_block_bootstrap(a,b,block=5,reps=2000,seed=42):
    """95% CI for mean daily strategy difference; contiguous blocks, paired days."""
    delta=np.asarray(b,dtype=float)-np.asarray(a,dtype=float)
    if len(delta)<block: return {'mean_diff':float(np.mean(delta)) if len(delta) else np.nan,'ci_low':np.nan,'ci_high':np.nan}
    rng=np.random.default_rng(seed);n=len(delta);means=[]
    for _ in range(reps):
        ids=[]
        while len(ids)<n:
            s=int(rng.integers(0,n-block+1));ids.extend(range(s,s+block))
        means.append(delta[np.array(ids[:n])].mean())
    lo,hi=np.percentile(means,[2.5,97.5])
    return {'mean_diff':float(delta.mean()),'ci_low':float(lo),'ci_high':float(hi)}

def regression(events, trades):
    """HAC OLS of signed open-to-15:55 return on signed gap and market dummy.
    Events need close_1555 column; no proxy or invented targets are used.
    """
    import statsmodels.api as sm
    if events.empty or 'close_1555' not in events:return None
    e=events.dropna(subset=['close_1555']).copy()
    if len(e)<30:return None
    e['y']=e.direction*(e.close_1555/e.day_open-1)
    X=sm.add_constant(pd.DataFrame({'abs_gap':e.gap.abs(),'is_nq':(e.symbol=='NQ').astype(int),'down_gap':(e.direction==-1).astype(int)}))
    return sm.OLS(e.y,X).fit(cov_type='HAC',cov_kwds={'maxlags':5})

def walkforward_logit(events, min_train=200):
    """Expanding window; features available at 09:30; labels at 15:55.
    Each date is held out as a unit across both instruments.
    """
    from sklearn.linear_model import LogisticRegression
    from sklearn.pipeline import make_pipeline
    from sklearn.preprocessing import StandardScaler
    from sklearn.metrics import brier_score_loss, roc_auc_score
    e=events.dropna(subset=['close_1555']).copy().sort_values(['date','symbol'])
    if e.empty:return pd.DataFrame(),{}
    e['label']=(e.direction*(e.close_1555/e.day_open-1)>0).astype(int)
    e['abs_gap']=e.gap.abs();e['is_nq']=(e.symbol=='NQ').astype(int);e['down_gap']=(e.direction==-1).astype(int)
    features=['abs_gap','is_nq','down_gap'];dates=sorted(e.date.unique());pred=[]
    for date in dates[min_train:]:
        train=e[e.date<date];test=e[e.date==date]
        if train.label.nunique()<2:continue
        model=make_pipeline(StandardScaler(),LogisticRegression(max_iter=1000))
        model.fit(train[features],train.label)
        for (_,r),prob in zip(test.iterrows(),model.predict_proba(test[features])[:,1]):
            pred.append({'symbol':r.symbol,'date':r.date,'actual':int(r.label),'probability':float(prob)})
    out=pd.DataFrame(pred)
    if out.empty:return out,{}
    metrics={'brier':float(brier_score_loss(out.actual,out.probability))}
    if out.actual.nunique()>1:metrics['roc_auc']=float(roc_auc_score(out.actual,out.probability))
    return out,metrics
