import argparse
from pathlib import Path
import pandas as pd
from .core import backtest,Config,validate,_clock
from .stats import daily_returns,performance,paired_block_bootstrap,regression,walkforward_logit

def main():
    parser=argparse.ArgumentParser(description='ES/NQ gap continuation research')
    parser.add_argument('--csv',required=True,help='UTC timestamp OHLCV CSV')
    parser.add_argument('--output',default='results')
    args=parser.parse_args();out=Path(args.output);out.mkdir(parents=True,exist_ok=True)
    raw=pd.read_csv(args.csv);df=validate(raw)
    trades,events=backtest(df,Config())
    if events.empty:raise SystemExit('No eligible sessions; check dates, session coverage, gap threshold')
    # Label only after 15:55 bar has completed, excluding incomplete days.
    closes=[]
    for (symbol,date),g in df.assign(date=df.timestamp.dt.date.astype(str)).groupby(['symbol','date']):
        bars=_clock(g,'15:55','15:56')
        if len(bars):closes.append({'symbol':symbol,'date':date,'close_1555':float(bars.iloc[0].close)})
    events=events.merge(pd.DataFrame(closes,columns=['symbol','date','close_1555']),on=['symbol','date'],how='left')
    trades.to_csv(out/'trades.csv',index=False);events.to_csv(out/'events.csv',index=False)
    daily=daily_returns(trades,events);daily.to_csv(out/'daily_returns.csv')
    with (out/'summary.txt').open('w') as f:
        for symbol,g in daily.groupby(level='symbol'):
            f.write(f'\n{symbol}\n')
            for strategy in g.columns:f.write(f'{strategy}: {performance(g[strategy])}\n')
            f.write(f'Paired block bootstrap (ICT minus immediate): {paired_block_bootstrap(g.immediate,g.ict_retracement)}\n')
        reg=regression(events,trades)
        f.write('\nHAC OLS:\n'+(str(reg.summary()) if reg is not None else 'Insufficient labeled events')+'\n')
        predictions,metrics=walkforward_logit(events)
        predictions.to_csv(out/'walkforward_predictions.csv',index=False)
        f.write('\nWalk-forward logistic metrics: '+str(metrics)+'\n')
    print(f'Research outputs saved to {out.resolve()}')
if __name__=='__main__':main()
