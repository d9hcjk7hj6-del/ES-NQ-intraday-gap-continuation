"""Signal definitions and conservative bar-based backtest. All timestamps America/New_York."""
from dataclasses import dataclass
import numpy as np
import pandas as pd

@dataclass(frozen=True)
class Config:
    gap_threshold: float = 0.0025
    opening_minutes: int = 15
    entry_deadline: str = "11:30"
    exit_time: str = "15:55"
    stop_points_es: float = 8.0
    stop_points_nq: float = 35.0
    reward_risk: float = 2.0
    cost_points_es: float = 0.5
    cost_points_nq: float = 2.0
    risk_budget_usd: float = 1000.0
    initial_capital_usd: float = 100_000.0

def validate(df):
    required = {"symbol", "timestamp", "open", "high", "low", "close", "volume"}
    if missing := required - set(df.columns):
        raise ValueError(f"Missing columns: {sorted(missing)}")
    x = df.copy()
    x["timestamp"] = pd.to_datetime(x["timestamp"], utc=True).dt.tz_convert("America/New_York")
    x = x.sort_values(["symbol", "timestamp"]).reset_index(drop=True)
    if x.duplicated(["symbol", "timestamp"]).any():
        raise ValueError("Duplicate symbol/timestamp")
    if ((x.high < x.low) | (x.high < x.open) | (x.high < x.close) | (x.low > x.open) | (x.low > x.close)).any():
        raise ValueError("Invalid OHLC")
    if (x.volume < 0).any():
        raise ValueError("Negative volume")
    return x

def three_candle_fvg(bars, direction):
    """Confirmed at third bar close; return midpoint and confirmation bar index."""
    if len(bars) < 3:
        return []
    found=[]
    for i in range(2,len(bars)):
        a,c=bars.iloc[i-2],bars.iloc[i]
        if direction == 1 and c.low > a.high:
            found.append((i, float((c.low+a.high)/2)))
        if direction == -1 and c.high < a.low:
            found.append((i, float((c.high+a.low)/2)))
    return found

def _clock(df, start, end):
    return df.loc[(df.timestamp.dt.strftime('%H:%M') >= start) & (df.timestamp.dt.strftime('%H:%M') < end)]

def _exit(bars, start_index, entry, direction, stop_points, rr, cost_points):
    """Stop-first convention if stop and target touched in same bar; exit at bar level.
    Gap-through fills and market impact are NOT modeled; see limitations.
    """
    stop=entry-direction*stop_points
    target=entry+direction*stop_points*rr
    for _,b in bars.iloc[start_index:].iterrows():
        if direction==1:
            stop_hit=b.low<=stop; target_hit=b.high>=target
        else:
            stop_hit=b.high>=stop; target_hit=b.low<=target
        if stop_hit:
            return float(stop), str(b.timestamp), 'stop'
        if target_hit:
            return float(target), str(b.timestamp), 'target'
    if len(bars):
        return float(bars.iloc[-1].close), str(bars.iloc[-1].timestamp), 'time'
    return np.nan, '', 'no_exit_bars'

def backtest(df, config=Config()):
    """One potential trade per strategy per symbol/day. RTH reference close is last
    available bar before 16:00 on prior RTH day, NOT futures settlement.
    All signals observed on completed bars; entries at subsequent bar open.
    """
    x=validate(df)
    trades=[]; events=[]
    for symbol,allbars in x.groupby('symbol'):
        if symbol not in ('ES','NQ'):
            raise ValueError('Only ES and NQ supported; map continuous contracts to these labels')
        point_value=50 if symbol=='ES' else 20
        stop_pts=config.stop_points_es if symbol=='ES' else config.stop_points_nq
        cost_pts=config.cost_points_es if symbol=='ES' else config.cost_points_nq
        # Fixed fractional notional sizing; fractional contracts prohibited.
        contracts=int(config.risk_budget_usd // (stop_pts*point_value))
        if contracts<1:
            raise ValueError(f'Risk budget too small for one {symbol} contract')
        allbars=allbars.copy();allbars['date']=allbars.timestamp.dt.date
        rth=_clock(allbars,'09:30','16:00')
        dates=sorted(rth.date.unique())
        for j in range(1,len(dates)):
            day=dates[j];prev=dates[j-1]
            prior=rth[rth.date==prev]; today=rth[rth.date==day].reset_index(drop=True)
            # Skip sessions without open and close coverage (half days, missing data).
            if len(prior)==0 or len(today)<40 or prior.iloc[-1].timestamp.strftime('%H:%M')<'15:55' or today.iloc[0].timestamp.strftime('%H:%M')!='09:30':
                continue
            prev_close=float(prior.iloc[-1].close)
            day_open=float(today.iloc[0].open)
            gap=day_open/prev_close-1
            if abs(gap)<config.gap_threshold:
                continue
            direction=1 if gap>0 else -1
            opening=today.iloc[:config.opening_minutes]
            if len(opening)<config.opening_minutes:continue
            or_high=float(opening.high.max());or_low=float(opening.low.min())
            events.append(dict(symbol=symbol,date=str(day),gap=gap,direction=direction,prev_close=prev_close,day_open=day_open,or_high=or_high,or_low=or_low))
            cutoff=today.index[today.timestamp.dt.strftime('%H:%M')>=config.exit_time]
            end_idx=int(cutoff[0]) if len(cutoff) else len(today)-1
            # Baseline: opening range confirmation at 09:45, enter NEXT bar open.
            i=config.opening_minutes
            if i<end_idx:
                entry=float(today.iloc[i].open)
                exit_price,exit_at,why=_exit(today.iloc[:end_idx+1],i,entry,direction,stop_pts,config.reward_risk,cost_pts)
                pnl=(exit_price-entry)*direction*point_value*contracts-cost_pts*point_value*contracts
                trades.append(dict(symbol=symbol,date=str(day),strategy='immediate',gap=gap,direction=direction,entry_at=str(today.iloc[i].timestamp),entry=entry,exit_at=exit_at,exit=exit_price,reason=why,contracts=contracts,pnl_usd=pnl,return_on_capital=pnl/config.initial_capital_usd))
            # ICT proxy: completed bar closes beyond opening range; directional FVG
            # subsequently confirmed; then a later bar trades through FVG midpoint;
            # enter at NEXT bar open, never at confirmation/retracement bar.
            deadline=today.index[today.timestamp.dt.strftime('%H:%M')>=config.entry_deadline]
            last=int(deadline[0]) if len(deadline) else end_idx
            chosen=None
            for k in range(config.opening_minutes+2,min(last,end_idx-1)):
                b=today.iloc[k]
                broke=(b.close>or_high) if direction==1 else (b.close<or_low)
                if not broke:continue
                a=today.iloc[k-2]
                valid=(b.low>a.high) if direction==1 else (b.high<a.low)
                if not valid:continue
                midpoint=float((b.low+a.high)/2) if direction==1 else float((b.high+a.low)/2)
                for m in range(k+1,min(last,end_idx-1)):
                    retraced=(today.iloc[m].low<=midpoint) if direction==1 else (today.iloc[m].high>=midpoint)
                    if retraced:
                        chosen=m+1;break
                if chosen is not None:break
            if chosen is not None:
                entry=float(today.iloc[chosen].open)
                exit_price,exit_at,why=_exit(today.iloc[:end_idx+1],chosen,entry,direction,stop_pts,config.reward_risk,cost_pts)
                pnl=(exit_price-entry)*direction*point_value*contracts-cost_pts*point_value*contracts
                trades.append(dict(symbol=symbol,date=str(day),strategy='ict_retracement',gap=gap,direction=direction,entry_at=str(today.iloc[chosen].timestamp),entry=entry,exit_at=exit_at,exit=exit_price,reason=why,contracts=contracts,pnl_usd=pnl,return_on_capital=pnl/config.initial_capital_usd))
    return pd.DataFrame(trades),pd.DataFrame(events)
